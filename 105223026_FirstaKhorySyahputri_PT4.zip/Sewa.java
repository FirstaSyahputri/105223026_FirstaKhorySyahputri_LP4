public class Sewa {
    Pelanggan pelanggan;
    Mobil mobil;
    int durasi;
    double totalBiaya;

    Sewa(Pelanggan pelanggan, Mobil mobil, int durasi) {
        this.pelanggan = pelanggan;
        this.mobil = mobil;
        this.durasi = durasi;
        this.totalBiaya = mobil.hargaSewa * durasi;
        if (durasi > 5) totalBiaya = Utility.hitungDiskon(totalBiaya);
    }

    void prosesPenyewaan() {
        if (mobil.tersedia) {
            mobil.tersedia = false;
            cetakStruk();
        } else {
            System.out.println("Transaksi gagal! Mobil tidak tersedia.");
        }
    }

    void cetakStruk() {
        System.out.println("#### Struk Penyewaan ####");
        pelanggan.tampilkanInfo();
        mobil.tampilkanInfo();
        System.out.println("Durasi = " + durasi + " hari");
        System.out.println("Total Biaya = " + Utility.formatMataUang(totalBiaya));
        System.out.println("Status = Berhasil");
        System.out.println();
    }
}