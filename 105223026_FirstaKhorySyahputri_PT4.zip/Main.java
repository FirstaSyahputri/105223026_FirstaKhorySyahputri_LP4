public class Main {
    public static void main(String[] args) {
        Mobil mobil1 = new Mobil("B 1213 VR", "BYD", 900000);
        Mobil mobil2 = new Mobil("D 5658 NP", "Cherry ", 1000000);
        Pelanggan pelanggan1 = new Pelanggan("Veer", "3201012345678901", "081234567890");

        System.out.println("#### Daftar Mobil ####");
        mobil1.tampilkanInfo();
        mobil2.tampilkanInfo();

        System.out.println("#### Transaksi Penyewaan ####");
        Sewa sewa1 = new Sewa(pelanggan1, mobil1, 6);
        sewa1.prosesPenyewaan();
    }
}