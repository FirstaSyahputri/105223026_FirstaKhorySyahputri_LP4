public class Mobil {
    String nomorPlat, merek;
    double hargaSewa;
    boolean tersedia;

    Mobil(String nomorPlat, String merek, double hargaSewa) {
        this.nomorPlat = nomorPlat;
        this.merek = merek;
        this.hargaSewa = hargaSewa;
        this.tersedia = true;
    }

    void tampilkanInfo() {
        System.out.println("Nomor Plat = " + nomorPlat);
        System.out.println("Merek = " + merek);
        System.out.println("Harga Sewa = " + Utility.formatMataUang(hargaSewa) + "/hari");
        System.out.println("Status = " + (tersedia ? "Tersedia" : "Tidak Tersedia"));
        System.out.println();
    }
}