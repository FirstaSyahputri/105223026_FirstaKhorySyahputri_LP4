public class Utility {
    static double hitungDiskon(double total) {
        return total * 0.9;
    }

    static String formatMataUang(double jumlah) {
        return "Rp " + String.format("%,.2f", jumlah);
    }
}
